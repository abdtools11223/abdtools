<?php
error_reporting(0);
if(!file_exists('admin.json')){
$token = readline('Enter Token : ');
$id = readline('Enter Id : ');
$save['info'] = [
'token'=>$token,
'id'=>$id
];
file_put_contents('admin.json',json_encode($save),64|128|256);
}
function save($array){
file_put_contents('admin.json',json_encode($array),64|128|256);
}
$token = json_decode(file_get_contents('admin.json'),true)['info']['token'];
$id = json_decode(file_get_contents('admin.json'),true)['info']['id'];
include 'index.php';
if($id == ""){
echo "Error Id";
}
try {
 $callback = function ($update, $bot) {
  global $id;
  if($update != null){
   if(isset($update->message)){
    $message = $update->message;
    $chat_id = $message->chat->id;   
    $name = $message->from->first_name;
    $message_id = $message->message_id;
    $text = $message->text;
$admin = json_decode(file_get_contents('admin.json'),true);
if($text == '/start' && $chat_id == $admin['info']['id']){
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"*
- اهلا وسهلا عزيزي $name  
- في بوت صيد حسابات انستقرام ✅ .
- قناة البوت : @ABDTOOLS
*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- اضف ملف 📁 .','callback_data'=>'upload'],['text'=>'- حذف ملف 📁 .','callback_data'=>'delete']],
[['text'=>'- بدء الصيد ✅ .','callback_data'=>'Start'],['text'=>'- إيقاف الفحص ❌ .','callback_data'=>'Stop']],
[['text'=>'- 𝗔𝗕𝗗 𝗧𝗢𝗢𝗟𝗦 ','url'=>'t.me/Abdtools']],
]
])
]);
}
$mode = file_get_contents("mode");
$token = json_decode(file_get_contents('admin.json'),true)['info']['token'];
define('API_KEY',"$token");
if($message->document && $mode == 'upload'){
$file = "https://api.telegram.org/file/bot".API_KEY."/".bot('getfile',['file_id'=>$message->document->file_id])->result->file_path;
file_put_contents('combo.txt',file_get_contents($file));
system("rm mode");
 bot('sendMessage',[
'chat_id'=>$id,
'text'=>"*
- تم اضافَة الملف ! .
- هل تريد البدء؟ .
*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- بدء ✅ .','callback_data'=>'Start']],
]
])
]);
}
if($text && $chat_id != $id){
bot('sendPhoto',[
'chat_id'=>$chat_id,
'photo'=>'https://t.me'.abdtools,
'caption'=>"*
- مرحباً عزيزي $name للمزيد اشترك ♥️
- قناة البوت : @abdtools .
- المطور  : @FFPPPPP .

*",
'parse_mode'=>'markdown',
]);
}
}
if(isset($update->callback_query)) {
    $chat_id1 = $update->callback_query->message->chat->id;
    $mid = $update->callback_query->message->message_id;
    $data = $update->callback_query->data;
    $message = $update->message;
    $chat_id = $message->chat->id;
    $text = $message->text;
    $name = $message->from->first_name;
if($data == 'upload'){
file_put_contents("mode","upload");
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"*
- الان ارسل لي الملف .
- يجب ان يكون الملف بصيغة {txt} .
*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع ⬅️ .','callback_data'=>'back']],
]
])
]);
}
if($data == 'Start'){
system("screen -dmS checker php make.php");
bot('deletemessage',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
]);
}
if($data == 'Stop'){
system("screen -S checker -X kill");
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"*
- تم الايقاف بنجاح ✅ . 
*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع ⬅️ .','callback_data'=>'back']],
]
])
]);
}
if($data == 'back'){
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"*
- اهلا وسهلا بيك عزيزي $name 
- بوت فحص حسابات انستقرام ✅ .
*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- أضف ملف 📁 .','callback_data'=>'upload'],['text'=>'- حذف ملف 📁 .','callback_data'=>'delete']],
[['text'=>'- بدء الفحص ✅ .','callback_data'=>'Start'],['text'=>'- ايقاف الفحص ❌ .','callback_data'=>'Stop']],
[['text'=>'- Dev .','url'=>'t.me/FFPPPPP']],
]
])
]);
}
if($data == 'delete'){
system("rm combo.txt");
bot('editMessageText',[
'chat_id'=>$chat_id1,
'message_id'=>$mid,
'text'=>"*
- تم حذف الملف بنجاح ✅ .
*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع ⬅️ .','callback_data'=>'back']],
]
])
]);
}
}
      }
    };
         $bot = new EzTG(array('throw_telegram_errors'=>true,'token' => $token, 'callback' => $callback));
  }
    catch(Exception $e){
 echo $e->getMessage().PHP_EOL;
 sleep(1);
}
